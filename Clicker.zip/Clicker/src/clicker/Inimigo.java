//Soli Deo Gloria

package clicker;

import javax.swing.ImageIcon;

class Inimigo extends Personagem{
    protected int attackSpeed;
    protected int dinheiro_que_dropa;
    protected int xp_que_dropa;

    public Inimigo(ImageIcon icone, String nome, int vidaMaxima, int dano, int chanceCritica, double MultiplicadorCritico, int attackSpeed, int dinheiro_que_dropa, int xp_que_dropa) {
        super(icone, nome, vidaMaxima, dano, chanceCritica, MultiplicadorCritico);
        this.attackSpeed = attackSpeed;
        this.dinheiro_que_dropa = dinheiro_que_dropa;
        this.xp_que_dropa = xp_que_dropa;
    }
    public Inimigo(String caminho, String nome, int vidaMaxima, int dano, int chanceCritica, double MultiplicadorCritico, int attackSpeed, int dinheiro_que_dropa, int xp_que_dropa) {
        super(caminho, nome, vidaMaxima, dano, chanceCritica, MultiplicadorCritico);
        this.attackSpeed = attackSpeed;
        this.dinheiro_que_dropa = dinheiro_que_dropa;
        this.xp_que_dropa = xp_que_dropa;
    }
    public void bater(Personagem p) {
        int danoFinal = this.dano;
        if(Math.random()*100 <= this.chanceCritica) {
            danoFinal *= this.MultiplicadorCritico;
        }
        p.vida -= danoFinal;
    }

}

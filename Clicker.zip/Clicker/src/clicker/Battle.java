//Soli Deo Gloria
package clicker;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.HashMap;
import java.util.Map;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JFrame;

public class Battle extends javax.swing.JPanel {

    public static HashMap<Integer, Inimigo> mapa = new HashMap<>();
    public static Inimigo enemy;

    /*
    icone OU caminho, nome, vidaMaxima, dano, chanceCritica, MultiplicadorCritico, dinheiro, nivel, xp_paraUpar,
    xp, pontos_de_status, pode_roubo_de_vida, roubo_de_vida, Inventario
     */
    public static Personagem voce = new Protagonista("cavaleiro", "Eu", 50, 2, 0, 0, 0, 0, 100, 0, 0, new Inventario());

    public Battle(JFrame frame) {
        this.setBounds(0, 0, frame.getWidth(), frame.getHeight());
        initComponents();
        frame.repaint();
        frame.revalidate();
        iniciarMapInimigos();
        lblEnemy.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                voce.bater(enemy);
            }
        }
        );

        DefaultComboBoxModel modelo = new DefaultComboBoxModel();

        for (int i = 0; i < mapa.size(); i++) {
            modelo.addElement(mapa.get(i).getNome());
        }
        cbxEnemy.setModel(modelo);

        btnStart.addMouseListener(
                new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {

                voce.setVida(voce.getVidaMaxima());
                btnStart.setVisible(false);
                cbxEnemy.setVisible(false);
                lblEnemy.setVisible(true);
                lblEnemy.setIcon(mapa.get(cbxEnemy.getSelectedIndex()).getIcone());
                enemy = new Inimigo(mapa.get(cbxEnemy.getSelectedIndex()));
                enemy.setVida(enemy.getVidaMaxima());

            }
        }
        );
    }

    public void gameLoop() throws InterruptedException {
        while (true) {
            if (enemy.vida <= 0) {
                return;
            } else {
                lblVida.setText("Vida: " + enemy.getVida());

            }
            Thread.sleep(16);
        }
    }

    public void iniciarMapInimigos() {
        //                      caminho            nome           vidaMaxima, dano, chanceCritica, MultiplicadorCritico, attackSpeed, dinheiro_que_dropa, xp_que_dropa
        final String inicioCaminho = "/clicker/imagens/";
        mapa.put(0, new Inimigo(inicioCaminho+"Bob_Esponja.png", "Bob Esponja", 50, 10, 24, 1.1, 3, 1, 3));
        mapa.put(1, new Inimigo(inicioCaminho+"Rainha_de_copas.jpg", "Rainha de copas", 550, 22, 10, 1.2, 2, 2, 4));
        mapa.put(2, new Inimigo(inicioCaminho+"Mario.jpg", "Mario", 900, 30, 10, 1.2, 3, 3, 6));
        mapa.put(3, new Inimigo(inicioCaminho+"Sonic.jpg", "Sonic", 1000, 90, 10, 1.2, 3, 5, 7));
        mapa.put(4, new Inimigo(inicioCaminho+"Shadow.jpg", "Shadow", 1200, 200, 35, 1.15, 3, 8, 11));
        mapa.put(5, new Inimigo(inicioCaminho+"Link.jpg", "Link", 2500, 300, 10, 1.4, 5, 13, 17));
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnStart = new javax.swing.JButton();
        cbxEnemy = new javax.swing.JComboBox<>();
        lblVoce = new javax.swing.JLabel();
        lblEnemy = new javax.swing.JLabel();
        lblVida = new javax.swing.JLabel();

        btnStart.setText("Start");
        btnStart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnStartActionPerformed(evt);
            }
        });

        cbxEnemy.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        lblVida.setText("Vida: ");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnStart)
                .addGap(28, 28, 28)
                .addComponent(cbxEnemy, javax.swing.GroupLayout.PREFERRED_SIZE, 279, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGap(105, 105, 105)
                .addComponent(lblVoce, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(120, 120, 120)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblVida)
                    .addComponent(lblEnemy, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(179, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addComponent(lblVida)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lblVoce, javax.swing.GroupLayout.DEFAULT_SIZE, 267, Short.MAX_VALUE)
                    .addComponent(lblEnemy, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(52, 52, 52)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnStart, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbxEnemy, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(85, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnStartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnStartActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnStartActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnStart;
    private javax.swing.JComboBox<String> cbxEnemy;
    private javax.swing.JLabel lblEnemy;
    private javax.swing.JLabel lblVida;
    private javax.swing.JLabel lblVoce;
    // End of variables declaration//GEN-END:variables
}

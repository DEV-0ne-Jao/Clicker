//Soli Deo Gloria

package clicker;

import java.awt.List;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;


public class ManipuladorDeArquivo {
    File arq = new File("Save.txt");
    
    public BufferedWriter bw;
    public BufferedReader br;
    public ManipuladorDeArquivo() {
        try {
            bw = new BufferedWriter(new FileWriter(arq));
            br = new BufferedReader(new FileReader(arq));
        } catch(FileNotFoundException exc) {
            
        } catch (IOException exc) {
            
        }
        
    }
    public String[] lerArquivo() {
        String linha;
        ArrayList<String> lista = new ArrayList<String>();
        try{
            if( (linha = br.readLine()) != null) {
                lista.add(linha);
            }
        } catch(IOException exc) {
            
        }
        String[] textoArquivo = new String[lista.size()]; 
        
        for(int i = 0; i<lista.size(); i++) {
            textoArquivo[i] = lista.get(i);
        }
        return textoArquivo;
        }
    public void escreverArquivo(String[] s) {
        
    }
        
}

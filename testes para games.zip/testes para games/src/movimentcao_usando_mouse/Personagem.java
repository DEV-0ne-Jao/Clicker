//Soli Deo Gloria
package movimentcao_usando_mouse;

import movimentacao_usando_angulos.*;
import javax.swing.ImageIcon;
import javax.swing.JLabel;

public class Personagem {
    private ImageIcon icone;
    private double direction;
    private int velocidade;
    private double x;
    private double y;
    private JLabel label = new JLabel();
    private Alvo alvo = new Alvo(0, 0);
    public Personagem(String caminho, double direction, int velocidade, double x, double y) {
        this.icone = new ImageIcon(getClass().getResource(caminho));
        this.direction = direction;
        this.velocidade = velocidade;
        this.x = x;
        this.y = y;
        this.label.setBounds((int)this.x, (int)this.y, 200, 200);
        this.label.setIcon(icone);
    }
    
    public void mover() {
        if( (int) this.x != (int) (this.alvo.getX() + (int) (this.label.getBounds().getWidth()/2))
           && (int) this.y != (int) this.alvo.getY() + (int) (this.label.getBounds().getHeight()/2)){
            this.direction = point_direction(this.x, this.y, alvo.getX(), alvo.getY());
            this.x += this.velocidade * Math.cos(this.direction);
            this.y += this.velocidade * Math.sin(this.direction);
        }
        this.label.setBounds((int)this.x, (int)this.y, 200, 200);
        this.label.repaint();
    }
    public double point_direction(double x1, double y1, double x2, double y2) {
        double dx = x2 - x1;
        double dy = y2 - y1;
        double direction = Math.atan2(dy, dx);
        return direction;
    }

    public ImageIcon getIcone() { return icone; }
    public double getDirection() { return direction; }
    public int getVelocidade() { return velocidade; }
    public double getX() { return x; }
    public double getY() { return y; }
    public JLabel getLabel() { return label; }
    public Alvo getAlvo() { return this.alvo; }
    
    public void setIcone(String caminho) { this.icone = new ImageIcon(getClass().getResource(caminho)); }
    public void setIcone(ImageIcon icone) { this.icone = icone; }
    public void setDirection(double direction) { this.direction = direction; }
    public void setVelocidade(int velocidade) { this.velocidade = velocidade; }
    public void setX(double x) { this.x = x; }
    public void setY(double y) { this.y = y; }
    public void setLabel(JLabel label){ this.label = label; }
    public void setAlvo(Alvo alvo) { this.alvo = alvo; }
    
}

//Soli Deo Gloria

package clicker;

import javax.swing.ImageIcon;

public class Item extends Inventoravel{
    
    private int preco;
    private ImageIcon icone;
    private String nome;
    private int vida = 0;
    private int dano = 0;
    private double chanceCritica = 0;
    private double multiplicadorCritico = 0;
    private double roubo_de_vida = 0;
    private String status = "<html>";
    private int posicaoNoMap;
    
    public Item(int preco, ImageIcon icone, String nome, Status[] status) {
        this.preco = preco;
        this.icone = icone;
        this.nome = nome;
        
        for(Status s : status) {
            switch(s.getNome()) {
                case "dano":
                    this.dano = s.getAtributoInt();
                    break;
                case "vida":
                    this.vida = s.getAtributoInt();
                    break;
                case "chancecritica":
                    this.chanceCritica = s.getAtributoDouble();
                    break;
                case "multiplicadorcritico":
                    this.multiplicadorCritico = s.getAtributoDouble();
                    break;
                case "roubodevida":
                    this.roubo_de_vida = s.getAtributoDouble();
                    break;
            }
        }
        if(this.vida > 0) {this.status += "Vida: " + this.vida + "<br>";}
        if(this.dano > 0) {this.status += "Dano: " + this.dano + "<br>";}
        if(this.chanceCritica > 0.0) {this.status += "Chance Crítica: " + this.chanceCritica + "<br>";
            System.out.println("Chance Criticou");}
        if(this.multiplicadorCritico > 0.0) {this.status += "\nMultiplicador Critico: " + this.multiplicadorCritico + "<br>";}
        if(this.roubo_de_vida > 0.0) {this.status += "Roubo de vida: " + this.roubo_de_vida + "<br>";}
        this.status += "</html>";
    }
    public Item(int preco, String caminho, String nome, Status[] status) {
        this.preco = preco;
        this.icone = new ImageIcon(caminho);
        this.nome = nome;
        
        for(Status s : status) {
            switch(s.getNome()) {
                case "dano":
                    this.dano = s.getAtributoInt();
                    break;
                case "vida":
                    this.vida = s.getAtributoInt();
                    break;
                case "chancecritica":
                    this.chanceCritica = s.getAtributoDouble();
                case "multiplicadorcritico":
                    this.multiplicadorCritico = s.getAtributoDouble();
                    break;
                case "roubodevida":
                    this.roubo_de_vida = s.getAtributoDouble();
                    break;
            }
        }
        if(this.vida > 0) {this.status += "Vida: " + this.vida + "<br>";}
        if(this.dano > 0) {this.status += "Dano: " + this.dano + "<br>";}
        if(this.chanceCritica > 0.0) {this.status += "Chance Crítica: " + this.chanceCritica + "<br>";}
        if(this.multiplicadorCritico > 0.0) {this.status += "\nMultiplicador Critico: " + this.multiplicadorCritico + "<br>";}
        if(this.roubo_de_vida > 0.0) {this.status += "Roubo de vida: " + this.roubo_de_vida + "<br>";}
        this.status += "</html>";
    }
    public Item(int preco, ImageIcon icone, String nome, Status status) {
        this.preco = preco;
        this.icone = icone;
        this.nome = nome;
        switch(status.getNome()) {
            case "dano":
                this.dano = status.getAtributoInt();
                break;
            case "vida":
                this.vida = status.getAtributoInt();
                break;
            case "chancecritica":
                this.chanceCritica = status.getAtributoDouble();
            case "multiplicadorcritico":
                this.multiplicadorCritico = status.getAtributoDouble();
                break;
            case "roubodevida":
                this.roubo_de_vida = status.getAtributoDouble();
                break;
        }
        if(this.vida > 0) {this.status += "Vida: " + this.vida + "<br>";}
        if(this.dano > 0) {this.status += "Dano: " + this.dano + "<br>";}
        if(this.chanceCritica > 0.0) {this.status += "Chance Crítica: " + this.chanceCritica + "<br>";}
        if(this.multiplicadorCritico > 0.0) {this.status += "\nMultiplicador Critico: " + this.multiplicadorCritico + "<br>";}
        if(this.roubo_de_vida > 0.0) {this.status += "Roubo de vida: " + this.roubo_de_vida + "<br>";}
        this.status += "</html>";
    }
    public Item(int preco, String caminho, String nome, Status status) {
        this.preco = preco;
        this.icone = new ImageIcon(caminho);
        this.nome = nome;
        switch(status.getNome()) {
            case "dano":
                this.dano = status.getAtributoInt();
                break;
            case "vida":
                this.vida = status.getAtributoInt();
                break;
            case "chancecritica":
                this.chanceCritica = status.getAtributoDouble();
            case "multiplicadorcritico":
                this.multiplicadorCritico = status.getAtributoDouble();
                break;
            case "roubodevida":
                this.roubo_de_vida = status.getAtributoDouble();
                break;
        }
        if(this.vida > 0) {this.status += "Vida: " + this.vida + "<br>";}
        if(this.dano > 0) {this.status += "Dano: " + this.dano + "<br>";}
        if(this.chanceCritica > 0.0) {this.status += "Chance Crítica: " + this.chanceCritica + "<br>";}
        if(this.multiplicadorCritico > 0.0) {this.status += "\nMultiplicador Critico: " + this.multiplicadorCritico + "<br>";}
        if(this.roubo_de_vida > 0.0) {this.status += "Roubo de vida: " + this.roubo_de_vida + "<br>";}
        this.status += "</html>";
    }

    public int getPreco() {return preco;}
    public ImageIcon getIcone() {return icone;}
    public String getNome() {return nome;}
    public int getVida() {return vida;}
    public int getDano() {return dano;}
    public double getChanceCritica() {return chanceCritica;}
    public double getMultiplicadorCritico() {return multiplicadorCritico;}
    public double getRoubo_de_vida() {return roubo_de_vida;}
    public String getStatus() {return status;}
    public int getPosicaoNoMap(){return posicaoNoMap;}

    public void setPreco(int preco) {this.preco = preco;}
    public void setIcone(ImageIcon icone) {this.icone = icone;}
    public void setNome(String nome) {this.nome = nome;}
    public void setVida(int vida) {this.vida = vida;}
    public void setDano(int dano) {this.dano = dano;}
    public void setChanceCritica(double chanceCritica) {this.chanceCritica = chanceCritica;}
    public void setMultiplicadorCritico(double multiplicadorCritico) {this.multiplicadorCritico = multiplicadorCritico;}
    public void setRoubo_de_vida(double roubo_de_vida) {this.roubo_de_vida = roubo_de_vida;}
    public void setPosicaoNoMap(int posicaoNoMap) {this.posicaoNoMap = posicaoNoMap;}
}

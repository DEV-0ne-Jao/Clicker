//Soli Deo Gloria
package clicker;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.HashMap;
import java.util.Map;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Battle extends javax.swing.JPanel {

    public static HashMap<Integer, Inimigo> mapa = new HashMap<>();
    public static Inimigo enemy;

    /*
    icone OU caminho, nome, vidaMaxima, dano, chanceCritica, MultiplicadorCritico, dinheiro, nivel, xp_paraUpar,
    xp, pontos_de_status, pode_roubo_de_vida, roubo_de_vida, Inventario
     */
    public static Protagonista voce = new Protagonista("/clicker/imagens/cavaleiro_templario.jpg", "Eu", 50, 2, 0, 0, 0, 0, 100, 0, 0, new Inventario());
    public Battle(JFrame frame) {
        this.setBounds(0, 0, frame.getWidth(), frame.getHeight());
        initComponents();
        iniciarComponentes();
        frame.repaint();
        frame.revalidate();
        iniciarMapInimigos();
        lblVoce.setIcon(voce.getIcone());
        lblEnemy.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                voce.bater(enemy);
            }
        }
        );

        DefaultComboBoxModel modelo = new DefaultComboBoxModel();

        for (int i = 0; i < mapa.size(); i++) {
            modelo.addElement(mapa.get(i).getNome());
        }
        cbxEnemy.setModel(modelo);

        btnStart.addMouseListener(
                new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {

                voce.setVida(voce.getVidaMaxima());
                btnStart.setVisible(false);
                cbxEnemy.setVisible(false);
                lblEnemy.setVisible(true);
                lblVidaVoce.setVisible(true);
                lblVidaEnemy.setVisible(true);
                lblEnemy.setIcon(mapa.get(cbxEnemy.getSelectedIndex()).getIcone());
                enemy = new Inimigo(mapa.get(cbxEnemy.getSelectedIndex()));
                enemy.setVida(enemy.getVidaMaxima());
                Thread tloop = new Thread(
                        new Runnable() {
                    public void run() {
                        gameLoop();
                    }
                });
                tloop.start();

            }
        }
        );
        btnInfos.addMouseListener(new MouseAdapter(){
            public void mouseClicked(MouseEvent e) {
                
            }
        } );
    }

    public void gameLoop() {
        try {
            int atackEnemy = enemy.getAttackSpeed();

            while (true) {
                atualizarInfos();
                if(voce.getVida() <= 0) {
                    btnStart.setVisible(true);
                    cbxEnemy.setVisible(true);
                    lblEnemy.setVisible(false);
                    lblVidaVoce.setVisible(false);
                    lblVidaEnemy.setVisible(false);
                    
                    JOptionPane.showMessageDialog(null, "Você perdeu", "Falha", JOptionPane.ERROR_MESSAGE);
                    
                    return;
                }
                if (enemy.getVida() <= 0) {
                    btnStart.setVisible(true);
                    cbxEnemy.setVisible(true);
                    lblEnemy.setVisible(false);
                    lblVidaVoce.setVisible(false);
                    lblVidaEnemy.setVisible(false);
                    
                    voce.somarXp( enemy.getXp_que_dropa() );
                    voce.setDinheiro( enemy.getDinheiro_que_dropa() );
                    voce.uparNivel();
                    
                    return;
                } else {

                    atackEnemy--;
                    if (atackEnemy <= 0) {
                        enemy.bater(voce);
                        atackEnemy = enemy.getAttackSpeed();
                    }
                }
                Thread.sleep(16);
            }
        } catch (InterruptedException exc) {

        }
    }
    public void iniciarComponentes() {
        lblVidaVoce.setVisible(false);
        lblVidaEnemy.setVisible(false);
    }
    
    public void atualizarInfos() {
        lblVidaEnemy.setText("Vida: " + enemy.getVida());
        lblVidaVoce.setText("Vida: " + voce.getVida());
    }

    public void iniciarMapInimigos() {
        //                      caminho            nome           vidaMaxima, dano, chanceCritica, MultiplicadorCritico, attackSpeed, dinheiro_que_dropa, xp_que_dropa
        final String inicioCaminho = "/clicker/imagens/";
        mapa.put(0, new Inimigo(inicioCaminho + "Bob_Esponja.png",     "Bob Esponja",     50,   10,  24, 1.1,  120, 1,  3));
        mapa.put(1, new Inimigo(inicioCaminho + "Rainha_de_copas.jpg", "Rainha de copas", 550,  22,  10, 1.2,  90,  2,  4));
        mapa.put(2, new Inimigo(inicioCaminho + "Mario.jpg",           "Mario",           900,  30,  10, 1.2,  130, 3,  6));
        mapa.put(3, new Inimigo(inicioCaminho + "Sonic.jpg",           "Sonic",           1000, 90,  10, 1.2,  70,  5,  7));
        mapa.put(4, new Inimigo(inicioCaminho + "Shadow.jpg",          "Shadow",          1200, 200, 35, 1.15, 65,  8,  11));
        mapa.put(5, new Inimigo(inicioCaminho + "Link.jpg",            "Link",            2500, 300, 10, 1.4,  80,  13, 17));
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnStart = new javax.swing.JButton();
        cbxEnemy = new javax.swing.JComboBox<>();
        lblVoce = new javax.swing.JLabel();
        lblEnemy = new javax.swing.JLabel();
        lblVidaEnemy = new javax.swing.JLabel();
        lblVidaVoce = new javax.swing.JLabel();
        btnInfos = new javax.swing.JButton();

        btnStart.setText("Start");
        btnStart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnStartActionPerformed(evt);
            }
        });

        cbxEnemy.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        lblVidaEnemy.setText("Vida: ");

        lblVidaVoce.setText("jLabel1");

        btnInfos.setText("Infos");
        btnInfos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInfosActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnStart)
                .addGap(28, 28, 28)
                .addComponent(cbxEnemy, javax.swing.GroupLayout.PREFERRED_SIZE, 279, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGap(105, 105, 105)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblVoce, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblVidaVoce))
                .addGap(120, 120, 120)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblVidaEnemy)
                    .addComponent(lblEnemy, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(179, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addComponent(btnInfos)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(btnInfos)
                .addGap(16, 16, 16)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblVidaEnemy)
                    .addComponent(lblVidaVoce))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lblVoce, javax.swing.GroupLayout.DEFAULT_SIZE, 267, Short.MAX_VALUE)
                    .addComponent(lblEnemy, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(52, 52, 52)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnStart, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbxEnemy, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(85, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnStartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnStartActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnStartActionPerformed

    private void btnInfosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInfosActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnInfosActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnInfos;
    private javax.swing.JButton btnStart;
    private javax.swing.JComboBox<String> cbxEnemy;
    private javax.swing.JLabel lblEnemy;
    private javax.swing.JLabel lblVidaEnemy;
    private javax.swing.JLabel lblVidaVoce;
    private javax.swing.JLabel lblVoce;
    // End of variables declaration//GEN-END:variables
}

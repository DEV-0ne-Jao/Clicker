//Soli Deo Gloria
package clicker;

import java.io.File;

public class Clicker {
    public static void main(String[] args) {

        Globals.inicializar();
        
        Globals.frame.setVisible(true);
        Globals.frame.setEnabled(true);
        Globals.frame.isActive();
    }
}
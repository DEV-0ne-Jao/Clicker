//Soli Deo Gloria
package clicker;
public class Clicker {
    public static void main(String[] args) {
         JFramePrincipal jframe = new JFramePrincipal();
         jframe.setVisible(true);
         jframe.setEnabled(true);
         jframe.isActive();
    }
}
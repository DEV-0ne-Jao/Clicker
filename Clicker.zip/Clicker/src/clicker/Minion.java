//Soli Deo Gloria
package clicker;

import javax.swing.ImageIcon;

class Minion extends Personagem{
    
    private int attackSpeed;

    public Minion(String caminho, String nome, int vidaMaxima, int dano, double chanceCritica, double MultiplicadorCritico, int attackSpeed) {
        super(caminho, nome, vidaMaxima, dano, chanceCritica, MultiplicadorCritico);
        this.attackSpeed = attackSpeed;
    }
}

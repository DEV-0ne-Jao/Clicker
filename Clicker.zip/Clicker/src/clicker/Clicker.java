//Soli Deo Gloria
package clicker;

import java.io.File;

public class Clicker {
    public static void main(String[] args) {

        Globals.inicializar();
    }
    public static void testes() {
        System.out.println("Frame Active: " + Globals.getFrame().isActive() );
        System.out.println("Frame Enabled: " + Globals.getFrame().isEnabled() );
        System.out.println("Frame Visible: " + Globals.getFrame().isVisible() );
        System.out.println("Frame Opaque: " + Globals.getFrame().isOpaque() );
        System.out.println("Frame Valid: " + Globals.getFrame().isValid() );
        
        System.out.println("Layer Enabled: " + Globals.getLayer().isEnabled() );
        System.out.println("Layer Visible: " + Globals.getLayer().isVisible() );
        System.out.println("Layer Opaque: " + Globals.getLayer().isOpaque() );
        System.out.println("Layer Valid: " + Globals.getLayer().isValid() );
        
        System.out.println("\nBounds Frame:"
                + "\nx: " + Globals.getFrame().getBounds().x
                + "\ny: " + Globals.getFrame().getBounds().y
                + "\nwidth: " + Globals.getFrame().getBounds().width
                + "\nheight: " + Globals.getFrame().getBounds().height);
        
        System.out.println("\nBounds Layer:"
                + "\nx:" + Globals.getLayer().getBounds().x
                + "\ny: " + Globals.getLayer().getBounds().y
                + "\nwidth: " + Globals.getLayer().getBounds().width
                + "\nheight: " + Globals.getLayer().getBounds().height);
    }
}
//Soli Deo Gloria

package clicker;

import java.util.ArrayList;

public class Inventario {
    private ArrayList<Inventoravel> guardados = new ArrayList<>();
    
    public void add(Inventoravel v) {
        guardados.add(v);
    }
}

//Soli Deo Gloria
package clicker;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;

public class Upar extends javax.swing.JPanel {

    public Upar() {
        initComponents();
        atualizarinfos();

        MouseAdapter m = new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (Globals.getProtagonista().getPontos_de_status() > 0) {
                    if (e.getSource() == btnVida) {
                        Globals.getProtagonista().setVidaMaxima(Globals.getProtagonista().getVidaMaxima() + 5);
                        Globals.getProtagonista().setPontos_de_status(Globals.getProtagonista().getPontos_de_status() - 1);
                        atualizarinfos();
                    } else if (e.getSource() == btnDano) {
                        Globals.getProtagonista().setDano(Globals.getProtagonista().getDano() + 1);
                        Globals.getProtagonista().setPontos_de_status(Globals.getProtagonista().getPontos_de_status() - 1);
                        atualizarinfos();
                    } else if (e.getSource() == btnChance) {
                        Globals.getProtagonista().setChanceCritica(Globals.getProtagonista().getChanceCritica() + 0.5);
                        Globals.getProtagonista().setPontos_de_status(Globals.getProtagonista().getPontos_de_status() - 1);
                        atualizarinfos();
                    } else if (e.getSource() == btnMult) {
                        Globals.getProtagonista().setMultiplicadorCritico(Globals.getProtagonista().getMultiplicadorCritico() + 0.7);
                        Globals.getProtagonista().setPontos_de_status(Globals.getProtagonista().getPontos_de_status() - 1);
                        atualizarinfos();
                    } else if (e.getSource() == btnRoubo) {
                        Globals.getProtagonista().setRoubo_de_vida(Globals.getProtagonista().getRoubo_de_vida() + 0.2);
                        Globals.getProtagonista().setPontos_de_status(Globals.getProtagonista().getPontos_de_status() - 1);
                        atualizarinfos();

                    }
                } else {
                    JOptionPane.showMessageDialog(null,"Pontos insuficientes", "Erro", JOptionPane.ERROR_MESSAGE);
                }
            }
        };

        btnVida.addMouseListener(m);
        btnDano.addMouseListener(m);
        btnChance.addMouseListener(m);
        btnMult.addMouseListener(m);
        btnRoubo.addMouseListener(m);
    }

    public void atualizarinfos() {
        l_Vida.setText("Vida máxima: " + Globals.getProtagonista().getVidaMaxima());
        l_Dano.setText("Dano: " + Globals.getProtagonista().getDano());
        l_ChanceCritica.setText("Chance crítica: " + Globals.getProtagonista().getChanceCritica());
        l_MultiplicadorCritico.setText("Multiplicador crítico: " + Globals.getProtagonista().getMultiplicadorCritico());
        l_RouboDeVida.setText("Roubo de vida: " + Globals.getProtagonista().getRoubo_de_vida());
        l_pts.setText("Pontos restantes: " + Globals.getProtagonista().getPontos_de_status());

        if (!Globals.getProtagonista().isPode_roubo_de_vida()) {
            btnRoubo.setEnabled(false);
        } else {
            btnRoubo.setEnabled(true);
        }

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        l_Vida = new javax.swing.JLabel();
        l_Dano = new javax.swing.JLabel();
        l_ChanceCritica = new javax.swing.JLabel();
        l_MultiplicadorCritico = new javax.swing.JLabel();
        l_RouboDeVida = new javax.swing.JLabel();
        btnVida = new javax.swing.JButton();
        btnDano = new javax.swing.JButton();
        btnChance = new javax.swing.JButton();
        btnMult = new javax.swing.JButton();
        btnRoubo = new javax.swing.JButton();
        l_pts = new javax.swing.JLabel();
        btnVoltar = new javax.swing.JButton();
        btnDeletarSave = new javax.swing.JButton();

        setBackground(new java.awt.Color(255, 255, 204));

        l_Vida.setText("Vida:");

        l_Dano.setText("Dano:");

        l_ChanceCritica.setText("Chance Crítica:");

        l_MultiplicadorCritico.setText("Multiplicador Crítico:");

        l_RouboDeVida.setText("Roubo de Vida:");

        btnVida.setText("+");

        btnDano.setText("+");

        btnChance.setText("+");

        btnMult.setText("+");

        btnRoubo.setText("+");

        l_pts.setText("Pontos restantes:");

        btnVoltar.setText("Voltar");
        btnVoltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVoltarActionPerformed(evt);
            }
        });

        btnDeletarSave.setText("Deletar save");
        btnDeletarSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeletarSaveActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(108, 108, 108)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(l_Dano, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(l_Vida, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(l_MultiplicadorCritico, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(l_ChanceCritica, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(l_pts, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(l_RouboDeVida, javax.swing.GroupLayout.Alignment.TRAILING))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnVida, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnDano, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnChance, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnMult, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnRoubo))
                .addGap(94, 94, 94)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnDeletarSave, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnVoltar, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(164, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(138, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnVida, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(l_Vida, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnDano, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(l_Dano, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnChance, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(l_ChanceCritica, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnMult, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(l_MultiplicadorCritico, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnRoubo)
                            .addComponent(l_RouboDeVida, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(29, 29, 29)
                        .addComponent(l_pts))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(btnVoltar)
                        .addGap(87, 87, 87)
                        .addComponent(btnDeletarSave)))
                .addGap(128, 128, 128))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnVoltarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVoltarActionPerformed
        Globals.getLayer().remove(this);
        Globals.getFrame().repaint();
        Globals.getFrame().revalidate();
    }//GEN-LAST:event_btnVoltarActionPerformed

    private void btnDeletarSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeletarSaveActionPerformed
        MP.apagarSave();
        Globals.setProtagonista( MP.lerSave() );
        atualizarinfos();
    }//GEN-LAST:event_btnDeletarSaveActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnChance;
    private javax.swing.JButton btnDano;
    private javax.swing.JButton btnDeletarSave;
    private javax.swing.JButton btnMult;
    private javax.swing.JButton btnRoubo;
    private javax.swing.JButton btnVida;
    private javax.swing.JButton btnVoltar;
    private javax.swing.JLabel l_ChanceCritica;
    private javax.swing.JLabel l_Dano;
    private javax.swing.JLabel l_MultiplicadorCritico;
    private javax.swing.JLabel l_RouboDeVida;
    private javax.swing.JLabel l_Vida;
    private javax.swing.JLabel l_pts;
    // End of variables declaration//GEN-END:variables
}

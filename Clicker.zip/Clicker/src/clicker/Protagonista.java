//Soli Deo Gloria
package clicker;

import javax.swing.ImageIcon;

public class Protagonista extends Personagem {

    private int dinheiro;
    private int nivel;
    private int xp_paraUpar;
    private int xp;
    private int pontos_de_status;
    private boolean pode_roubo_de_vida;
    private double roubo_de_vida;
    private Inventario Inventario;

    public Protagonista(ImageIcon icone, String nome, int vidaMaxima, int dano, int chanceCritica, double MultiplicadorCritico,
            int dinheiro, int nivel, int xp_paraUpar, int xp, int pontos_de_status, boolean pode_roubo_de_vida,
            double roubo_de_vida, Inventario Inventario) {
        super(icone, nome, vidaMaxima, dano, chanceCritica, MultiplicadorCritico);
        this.dinheiro = dinheiro;
        this.nivel = nivel;
        this.xp_paraUpar = xp_paraUpar;
        this.xp = xp;
        this.pontos_de_status = pontos_de_status;
        this.pode_roubo_de_vida = pode_roubo_de_vida;
        this.roubo_de_vida = roubo_de_vida;
        this.Inventario = Inventario;
    }

    public Protagonista(ImageIcon icone, String nome, int vidaMaxima, int dano, int chanceCritica, double MultiplicadorCritico,
            int dinheiro, int nivel, int xp_paraUpar, int xp, int pontos_de_status, Inventario Inventario) {
        super(icone, nome, vidaMaxima, dano, chanceCritica, MultiplicadorCritico);
        this.dinheiro = dinheiro;
        this.nivel = nivel;
        this.xp_paraUpar = xp_paraUpar;
        this.xp = xp;
        this.pontos_de_status = pontos_de_status;
        this.pode_roubo_de_vida = false;
        this.roubo_de_vida = 0;
        this.Inventario = Inventario;
    }

    public Protagonista(String caminho, String nome, int vidaMaxima, int dano, int chanceCritica, double MultiplicadorCritico,
            int dinheiro, int nivel, int xp_paraUpar, int xp, int pontos_de_status, boolean pode_roubo_de_vida,
            double roubo_de_vida, Inventario Inventario) {
        super(caminho, nome, vidaMaxima, dano, chanceCritica, MultiplicadorCritico);
        this.dinheiro = dinheiro;
        this.nivel = nivel;
        this.xp_paraUpar = xp_paraUpar;
        this.xp = xp;
        this.pontos_de_status = pontos_de_status;
        this.pode_roubo_de_vida = pode_roubo_de_vida;
        this.roubo_de_vida = roubo_de_vida;
        this.Inventario = Inventario;
    }
    public Protagonista(String caminho, String nome, int vidaMaxima, int dano, int chanceCritica, double MultiplicadorCritico,
            int dinheiro, int nivel, int xp_paraUpar, int xp, int pontos_de_status, Inventario Inventario) {
        super(caminho, nome, vidaMaxima, dano, chanceCritica, MultiplicadorCritico);
        this.dinheiro = dinheiro;
        this.nivel = nivel;
        this.xp_paraUpar = xp_paraUpar;
        this.xp = xp;
        this.pontos_de_status = pontos_de_status;
        this.pode_roubo_de_vida = false;
        this.roubo_de_vida = 0;
        this.Inventario = Inventario;
    }

    public void bater(Personagem p) {
        int danoFinal = this.dano;
        if (Math.random() * 100 <= this.chanceCritica) {
            danoFinal *= this.MultiplicadorCritico;
        }
        if(this.pode_roubo_de_vida) {
            this.vida += (danoFinal*this.roubo_de_vida);
        }
        p.vida -= danoFinal;
    }

}

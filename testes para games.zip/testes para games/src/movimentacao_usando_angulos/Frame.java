package movimentacao_usando_angulos;

//Soli Deo Gloria
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Frame extends javax.swing.JFrame {

    Personagem p = new Personagem("/movimentacao_usando_angulos/nave.jpg", Math.PI/2, 10, 0, 0);
    public boolean w = false;
    public boolean a = false;
    public boolean s = false;
    public boolean d = false;

    public Frame() {
        initComponents();
        this.addKeyListener(new KeyListener() {
            public void keyTyped(KeyEvent e) {
            }

            public void keyPressed(KeyEvent e) {
                if (e.getKeyChar() == 'w') {
                    w = true;
                }
                if (e.getKeyChar() == 'a') {
                    a = true;
                }
                if (e.getKeyChar() == 's') {
                    s = true;
                }
                if (e.getKeyChar() == 'd') {
                    d = true;
                }
            }

            public void keyReleased(KeyEvent e) {
                if (e.getKeyChar() == 'w') {
                    w = false;
                }
                if (e.getKeyChar() == 'a') {
                    a = false;
                }
                if (e.getKeyChar() == 's') {
                    s = false;
                }
                if (e.getKeyChar() == 'd') {
                    d = false;
                }
            }
        });
        this.add(p.getLabel());
        Thread t1 = new Thread(new Runnable() {
            public void run() {
                gameloop();
            }
        });
        t1.start();
    }

    public void gameloop() {
        while (true) {//
            try {
                coisar(p);
                p.getLabel().repaint();
                Thread.sleep(16);
            } catch (InterruptedException ex) {
            }
        }
    }

    public void coisar(Personagem p) {
        if (w) {
            if (p.getVelocidade() < 0) {
                p.setVelocidade(-p.getVelocidade());
            }
            p.mover();
        }
        if (a) {
            p.setDirection(p.getDirection() - 0.02);
        }
        if (s) {
            if (p.getVelocidade() > 0) {
                p.setVelocidade(-p.getVelocidade());
            }
            p.mover();
        }
        if (d) {
            p.setDirection(p.getDirection() +0.02);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Soli Deo Gloria");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(317, 317, 317)
                .addComponent(jLabel1)
                .addContainerGap(406, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addContainerGap(478, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Frame().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    // End of variables declaration//GEN-END:variables
}

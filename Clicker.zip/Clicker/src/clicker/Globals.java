//Soli Deo Gloria
package clicker;

import java.io.File;

public class Globals {

    public static Protagonista protagonista;
    public static JFramePrincipal frame;

    public static void carregarSave() {
        File arq = new File("Save.txt");
        if (arq.exists()) {
            protagonista = MP.lerSave();
        } else {
            protagonista = new Protagonista("/clicker/imagens/cavaleiro_templario.jpg", "Eu", 50, 2, 0, 0, 0, 0, 7, 0, 0, new Inventario());
        }
    }
    public static void inicializar() {
        carregarSave();
        frame = new JFramePrincipal();
        frame.add( new Lobby() );
    }

    public static Protagonista getProtagonista() {return protagonista;}
    public static void setProtagonista(Protagonista p) {Globals.protagonista = p;}
}

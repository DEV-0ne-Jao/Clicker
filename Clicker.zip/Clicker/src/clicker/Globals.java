//Soli Deo Gloria
package clicker;

import java.awt.Dimension;
import java.io.File;
import java.util.HashMap;
import javax.swing.ImageIcon;
import javax.swing.JLayeredPane;

public class Globals {

    private static Protagonista protagonista;
    private static JFramePrincipal frame = new JFramePrincipal();
    private static JLayeredPane layer = new JLayeredPane();
    private static HashMap<Integer, Item> itens = new HashMap<>();   

    public static void carregarSave() {
        File arq = new File("Save.txt");
        if (arq.exists()) {
            protagonista = MP.lerSave();
        } else {
            protagonista = new Protagonista("/clicker/imagens/cavaleiro_templario.jpg", "Eu", 50, 2, 0, 0, 0, 0, 7, 0, 0, new Inventario());
        }
    }
    public static void inicializar() {
        carregarSave();

        frame.setBounds(0, 0, 800, 600);
        frame.add( Globals.layer );
        layer.setBounds(Globals.frame.getBounds());
        layer.add( new Lobby(), 0 );
        
        frame.setVisible(true);
        frame.setEnabled(true);
        
        layer.setVisible(true);
        layer.setEnabled(true);
        
        Item[] items = {
            new Item(10, new ImageIcon( Globals.class.getResource("/clicker/imagens/EspadaNivel1.png") ), "Espada de madeira", new Status("dano", 2)),
            new Item(150, new ImageIcon( Globals.class.getResource("/clicker/imagens/EspadaNivel2.png") ), "Espada de ferro", new Status("dano", 5)),
            new Item(650, new ImageIcon( Globals.class.getResource("/clicker/imagens/EspadaNivel3.png") ), "Espada de rubi", new Status("dano", 10)),
            new Item(1900, new ImageIcon( Globals.class.getResource("/clicker/imagens/PaxelDeMadeira.png") ), "Paxel de madeira", new Status[]{new Status("dano", 10),new Status("vida", 10)}),
            new Item(3000, new ImageIcon( Globals.class.getResource("/clicker/imagens/RompedorDeEclipse.png") ), "Rompedor de Eclipse", new Status[]{new Status("dano", 30), new Status("vida", 10), new Status("chancecritica", 2.0)})
        };
        
        for(int i=0; i<items.length; i++){
            itens.put(i, items[i] );
        }
    }
    public static Protagonista getProtagonista() {return protagonista;}
    public static JFramePrincipal getFrame() {return frame;}
    public static JLayeredPane getLayer() {return layer;}
    public static HashMap<Integer, Item> getItens() {return itens;}

    public static void setProtagonista(Protagonista p) {Globals.protagonista = p;}
    public static void setFrame(JFramePrincipal Frame) {frame = Frame;}
    public static void setLayer(JLayeredPane Layer) {layer = Layer;}
}

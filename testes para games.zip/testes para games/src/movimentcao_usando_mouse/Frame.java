package movimentcao_usando_mouse;

//Soli Deo Gloria
import movimentacao_usando_angulos.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Frame extends javax.swing.JFrame {

    Personagem p = new Personagem("/movimentacao_usando_angulos/nave.jpg", Math.PI/2, 10, 0, 0);

    public Frame() {
        initComponents();
        this.setFocusable(true);
        this.requestFocusInWindow();
        this.requestFocus();
        System.out.println("Tem foco: " + this.isFocusOwner());
        this.add(p.getLabel());
        this.addMouseListener( new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                System.out.print("Clicou!  ");
                p.setAlvo(new  Alvo( e.getX(), e.getY() ) );
                System.out.println("X: " + p.getAlvo().getX() + "  Y:" + p.getAlvo().getY());
            }
        });
        new javax.swing.Timer(16, e -> {
            p.mover();
            System.out.println("X do alvo: " + p.getAlvo().getX() + "  Y do alvo:" + p.getAlvo().getY()
            + "\nX do personagem: " + p.getLabel().getBounds().getX()
            + "Y do personagem: " + p.getLabel().getBounds().getY());
        }).start();
    }

    public void gameloop() {
        while (true) {//
            try {
                p.mover();
                p.getLabel().repaint();
                Thread.sleep(16);
            } catch (InterruptedException ex) {
            }
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Soli Deo Gloria");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(317, 317, 317)
                .addComponent(jLabel1)
                .addContainerGap(406, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addContainerGap(478, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Frame().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    // End of variables declaration//GEN-END:variables
}

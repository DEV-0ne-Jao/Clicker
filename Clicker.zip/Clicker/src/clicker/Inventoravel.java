//Soli Deo Gloria
package clicker;

public class Inventoravel {
    
}

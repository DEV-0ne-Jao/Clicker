//Soli Deo Gloria
package clicker;

import java.awt.List;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ManipuladorDeArquivo {

    public BufferedWriter bw;
    public BufferedReader br;

    public ManipuladorDeArquivo() {
    }

    public String[] lerArquivo() {
        try {
            br = new BufferedReader(new FileReader("Save.txt"));
        } catch (FileNotFoundException ex) {
        }
        String linha;
        ArrayList<String> lista = new ArrayList<String>();
        try {
            while ((linha = br.readLine()) != null) {
                lista.add(linha);
            }
        } catch (IOException exc) {

        }
        String[] textoArquivo = new String[lista.size()];

        for (int i = 0; i < lista.size(); i++) {
            textoArquivo[i] = lista.get(i);
        }
        try {
            br.close();
        } catch (IOException ex) {
        }
        return textoArquivo;
    }

    public Protagonista lerSave() {
        Protagonista p;
        String linha;
        String textoArquivo = "";
        try {
            br = new BufferedReader(new FileReader("Save.txt"));
        } catch (FileNotFoundException ex) {
        }
        try {
            while ((linha = br.readLine()) != null) {
                textoArquivo += linha;
            }
        } catch (IOException exc) {
        }
        System.out.println(textoArquivo);
        String[] informacoes = textoArquivo.split("\\|");
        p = new Protagonista(
                informacoes[0], //caminho
                informacoes[1], //nome
                Integer.parseInt(informacoes[2]), //vida maxima
                Integer.parseInt(informacoes[3]), // dano
                Double.parseDouble(informacoes[4]), //chance crítica
                Double.parseDouble(informacoes[5]), //multiplicador critico
                Integer.parseInt(informacoes[6]), //dinheiro
                Integer.parseInt(informacoes[7]), //nivel
                Integer.parseInt(informacoes[8]), //xp para upar
                Integer.parseInt(informacoes[9]), //xp
                Integer.parseInt(informacoes[10]), //pontos de status
                Boolean.parseBoolean(informacoes[11]), //pode roubar vida
                Double.parseDouble(informacoes[12]), //roubo de vida
                new Inventario() //Inventario

        );
        try {
            br.close();
        } catch (IOException ex) {
        }

        return p;
    }

    public void escreverArquivo(String[] s) {
        try {
            bw = new BufferedWriter(new FileWriter("Save.txt"));

            String infos = "";
            for (String info : s) {
                infos += info + "|";
            }

            bw.write(infos);
            bw.flush();
            bw.close();
            System.out.println("Escrito com sucesso");
        } catch (IOException exc) {
            System.out.println("O save falhou");
        }
    }

    public void escreverSave(Protagonista p) {
        try {
            bw = new BufferedWriter(new FileWriter("Save.txt"));

            String infos
                    = p.getCaminho() + "|"
                    + p.getNome() + "|"
                    + p.getVidaMaxima() + "|"
                    + p.getDano() + "|"
                    + p.getChanceCritica() + "|"
                    + p.getMultiplicadorCritico() + "|"
                    + p.getDinheiro() + "|"
                    + p.getNivel() + "|"
                    + p.getXp_paraUpar() + "|"
                    + p.getXp() + "|"
                    + p.getPontos_de_status() + "|"
                    + p.isPode_roubo_de_vida() + "|"
                    + p.getRoubo_de_vida();
            System.out.println(infos);

            bw.write(infos);
            bw.flush();
            bw.close();
            System.out.println("Escrito com sucesso");
        } catch (IOException exc) {
            System.out.println("O save falhou");
        }

    }

    public void deletarArquivo() {
        File arq = new File("Save.txt");
        arq.delete();
        System.out.println("Deletado com sucesso");
    }
}

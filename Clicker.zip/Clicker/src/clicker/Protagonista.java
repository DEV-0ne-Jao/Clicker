//Soli Deo Gloria
package clicker;

import javax.swing.ImageIcon;

public class Protagonista extends Personagem {

    private int dinheiro;
    private int nivel;
    private int xp_paraUpar;
    private int xp;
    private int pontos_de_status;
    private boolean pode_roubo_de_vida;
    private double roubo_de_vida;
    private Inventario Inventario;

    public Protagonista(ImageIcon icone, String nome, int vidaMaxima, int dano, double chanceCritica, double MultiplicadorCritico,
            int dinheiro, int nivel, int xp_paraUpar, int xp, int pontos_de_status, boolean pode_roubo_de_vida,
            double roubo_de_vida, Inventario Inventario) {
        super(icone, nome, vidaMaxima, dano, chanceCritica, MultiplicadorCritico);
        this.dinheiro = dinheiro;
        this.nivel = nivel;
        this.xp_paraUpar = xp_paraUpar;
        this.xp = xp;
        this.pontos_de_status = pontos_de_status;
        this.pode_roubo_de_vida = pode_roubo_de_vida;
        this.roubo_de_vida = roubo_de_vida;
        this.Inventario = Inventario;
    }

    public Protagonista(ImageIcon icone, String nome, int vidaMaxima, int dano, double chanceCritica, double MultiplicadorCritico,
            int dinheiro, int nivel, int xp_paraUpar, int xp, int pontos_de_status, Inventario Inventario) {
        super(icone, nome, vidaMaxima, dano, chanceCritica, MultiplicadorCritico);
        this.dinheiro = dinheiro;
        this.nivel = nivel;
        this.xp_paraUpar = xp_paraUpar;
        this.xp = xp;
        this.pontos_de_status = pontos_de_status;
        this.pode_roubo_de_vida = false;
        this.roubo_de_vida = 0;
        this.Inventario = Inventario;
    }

    public Protagonista(String caminho, String nome, int vidaMaxima, int dano, double chanceCritica, double MultiplicadorCritico,
            int dinheiro, int nivel, int xp_paraUpar, int xp, int pontos_de_status, boolean pode_roubo_de_vida,
            double roubo_de_vida, Inventario Inventario) {
        super(caminho, nome, vidaMaxima, dano, chanceCritica, MultiplicadorCritico);
        this.dinheiro = dinheiro;
        this.nivel = nivel;
        this.xp_paraUpar = xp_paraUpar;
        this.xp = xp;
        this.pontos_de_status = pontos_de_status;
        this.pode_roubo_de_vida = pode_roubo_de_vida;
        this.roubo_de_vida = roubo_de_vida;
        this.Inventario = Inventario;
    }

    public Protagonista(String caminho, String nome, int vidaMaxima, int dano, double chanceCritica, double MultiplicadorCritico,
            int dinheiro, int nivel, int xp_paraUpar, int xp, int pontos_de_status, Inventario Inventario) {
        super(caminho, nome, vidaMaxima, dano, chanceCritica, MultiplicadorCritico);
        this.dinheiro = dinheiro;
        this.nivel = nivel;
        this.xp_paraUpar = xp_paraUpar;
        this.xp = xp;
        this.pontos_de_status = pontos_de_status;
        this.pode_roubo_de_vida = false;
        this.roubo_de_vida = 0;
        this.Inventario = Inventario;
    }

    
    public void somarXp(int xp) {
        this.xp += xp;
    }
    public void somarDinheiro(int dinheiro) {
        this.dinheiro += dinheiro;
    }
    
    public int getDinheiro() {
        return dinheiro;
    }

    public void setDinheiro(int dinheiro) {
        this.dinheiro = dinheiro;
    }

    public int getNivel() {
        return nivel;
    }

    public void setNivel(int nivel) {
        this.nivel = nivel;
    }

    public int getXp_paraUpar() {
        return xp_paraUpar;
    }

    public void setXp_paraUpar(int xp_paraUpar) {
        this.xp_paraUpar = xp_paraUpar;
    }

    public int getXp() {
        return xp;
    }

    public void setXp(int xp) {
        this.xp = xp;
    }

    public int getPontos_de_status() {
        return pontos_de_status;
    }

    public void setPontos_de_status(int pontos_de_status) {
        this.pontos_de_status = pontos_de_status;
    }

    public boolean isPode_roubo_de_vida() {
        return pode_roubo_de_vida;
    }

    public void setPode_roubo_de_vida(boolean pode_roubo_de_vida) {
        this.pode_roubo_de_vida = pode_roubo_de_vida;
    }

    public double getRoubo_de_vida() {
        return roubo_de_vida;
    }

    public void setRoubo_de_vida(double roubo_de_vida) {
        this.roubo_de_vida = roubo_de_vida;
    }

    public Inventario getInventario() {
        return Inventario;
    }

    public void setInventario(Inventario Inventario) {
        this.Inventario = Inventario;
    }

    public void uparNivel() {
        if(this.xp >= this.xp_paraUpar) {
            this.nivel++;
            this.pontos_de_status++;
            this.xp -= this.xp_paraUpar;
        } else {
            System.out.println("Xp insuficiente");
        }
    }
    public void bater(Personagem p) {
        if (p.vida > 0) {
            int danoFinal = this.dano;
            if (Math.random() * 100 <= this.chanceCritica) {
                danoFinal += danoFinal * this.MultiplicadorCritico/100;
            }
            if (this.pode_roubo_de_vida) {
                this.vida += (danoFinal * this.roubo_de_vida);
            }
            if( p.vida - danoFinal < 0) {
                p.vida = 0;
            } else {
                p.vida -= danoFinal;
            };
        }
    }

}

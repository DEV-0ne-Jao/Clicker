//Soli Deo Gloria
package clicker;

import javax.swing.ImageIcon;

class Inimigo extends Personagem {

    protected int attackSpeed;
    protected int dinheiro_que_dropa;
    protected int xp_que_dropa;
    protected String dropEspecial;

    public Inimigo(ImageIcon icone, String nome, int vidaMaxima, int dano, int chanceCritica, double MultiplicadorCritico, int attackSpeed, int dinheiro_que_dropa, int xp_que_dropa, String dropEspecial) {
        super(icone, nome, vidaMaxima, dano, chanceCritica, MultiplicadorCritico);
        this.attackSpeed = attackSpeed;
        this.dinheiro_que_dropa = dinheiro_que_dropa;
        this.xp_que_dropa = xp_que_dropa;
        this.dropEspecial = dropEspecial;
    }

    public Inimigo(String caminho, String nome, int vidaMaxima, int dano, int chanceCritica, double MultiplicadorCritico, int attackSpeed, int dinheiro_que_dropa, int xp_que_dropa, String dropEspecial) {
        super(caminho, nome, vidaMaxima, dano, chanceCritica, MultiplicadorCritico);
        this.attackSpeed = attackSpeed;
        this.dinheiro_que_dropa = dinheiro_que_dropa;
        this.xp_que_dropa = xp_que_dropa;
        this.dropEspecial = dropEspecial;
    }

    public Inimigo(Inimigo i) {
        super(i.getIcone(), i.getNome(), i.getVidaMaxima(), i.getDano(), i.getChanceCritica(), i.getMultiplicadorCritico());
        this.attackSpeed = i.getAttackSpeed();
        this.dinheiro_que_dropa = i.getDinheiro_que_dropa();
        this.xp_que_dropa = i.getXp_que_dropa();
        this.dropEspecial = i.getDropEspecial();
    }

    public void bater(Personagem p) {
        if (p.vida > 0) {
            int danoFinal = this.dano;

            if (Math.random() * 100 <= this.chanceCritica) {
                danoFinal += danoFinal * this.MultiplicadorCritico/100;
            }
            if( p.vida - danoFinal < 0) {
                p.vida = 0;
            } else {
                p.vida -= danoFinal;
            }
        }
    }

    public int getAttackSpeed() {return attackSpeed;}
    public int getDinheiro_que_dropa() {return dinheiro_que_dropa;}
    public int getXp_que_dropa() {return xp_que_dropa;}
    public String getDropEspecial() {return dropEspecial;}
    
    public void setAttackSpeed(int attackSpeed) {this.attackSpeed = attackSpeed;}
    public void setDinheiro_que_dropa(int dinheiro_que_dropa) {this.dinheiro_que_dropa = dinheiro_que_dropa;}
    public void setXp_que_dropa(int xp_que_dropa) {this.xp_que_dropa = xp_que_dropa;}
    public void setDropEspecial(String dropEspecial) {this.dropEspecial = dropEspecial;}

}

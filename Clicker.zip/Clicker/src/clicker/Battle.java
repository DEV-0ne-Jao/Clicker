//Soli Deo Gloria

package clicker;

import java.util.HashMap;
import java.util.Map;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JFrame;

public class Battle extends javax.swing.JPanel {
    public static HashMap<Integer, Inimigo> mapa = new HashMap<>();
    public Battle(JFrame frame) {
        initComponents();
        iniciarMapInimigos();
        
        DefaultComboBoxModel modelo = new DefaultComboBoxModel();
        
        for(int i=0; i<mapa.size(); i++) {
            modelo.addElement(mapa.get(i).getNome());
        }
        cbxEnemy.setModel(modelo);
    }
    
    public void iniciarMapInimigos() {
        //                      caminho            nome           vidaMaxima, dano, chanceCritica, MultiplicadorCritico, attackSpeed, dinheiro_que_dropa, xp_que_dropa
        mapa.put(0, new Inimigo("Bob_Esponja.png", "Bob Esponja", 300,        10,   24,            1.1,                  3,           1,                  3));
        mapa.put(3, new Inimigo("Rainha_de_copas.png", "Rainha de copas", 550, 22, 10, 1.2, 2, 2, 4));
        mapa.put(1, new Inimigo("Mario.png", "Mario", 900, 30, 10, 1.2, 3, 3, 6));
        mapa.put(2, new Inimigo("Sonic.png", "Sonic", 1000, 90, 10, 1.2, 3, 5, 7));
        mapa.put(3, new Inimigo("Shadow.png", "Shadow", 1200, 200, 35, 1.15, 3, 8, 11) );
        mapa.put(4, new Inimigo("Link.png", "Link", 2500, 300, 10, 1.4, 5, 13, 17) );
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnStart = new javax.swing.JButton();
        cbxEnemy = new javax.swing.JComboBox<>();
        lblVoce = new javax.swing.JLabel();
        lblEnemy = new javax.swing.JLabel();

        btnStart.setText("Start");
        btnStart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnStartActionPerformed(evt);
            }
        });

        cbxEnemy.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        lblVoce.setText("jLabel1");

        lblEnemy.setText("jLabel2");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnStart)
                .addGap(28, 28, 28)
                .addComponent(cbxEnemy, javax.swing.GroupLayout.PREFERRED_SIZE, 279, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGap(105, 105, 105)
                .addComponent(lblVoce, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(120, 120, 120)
                .addComponent(lblEnemy, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(179, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(61, 61, 61)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lblVoce, javax.swing.GroupLayout.DEFAULT_SIZE, 267, Short.MAX_VALUE)
                    .addComponent(lblEnemy, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(52, 52, 52)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnStart, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbxEnemy, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(85, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnStartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnStartActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnStartActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnStart;
    private javax.swing.JComboBox<String> cbxEnemy;
    private javax.swing.JLabel lblEnemy;
    private javax.swing.JLabel lblVoce;
    // End of variables declaration//GEN-END:variables
}

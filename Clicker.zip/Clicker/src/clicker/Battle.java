//Soli Deo Gloria
package clicker;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.HashMap;
import java.util.Map;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

public class Battle extends javax.swing.JPanel {

    public static HashMap<Integer, Inimigo> mapa = new HashMap<>();
    public static Inimigo enemy;

    /*
    icone OU caminho, nome, vidaMaxima, dano, chanceCritica, MultiplicadorCritico, dinheiro, nivel, xp_paraUpar,
    xp, pontos_de_status, pode_roubo_de_vida, roubo_de_vida, Inventario
     */
    public Battle() {
        this.setBounds(Globals.getLayer().getBounds());
        initComponents();
        iniciarComponentes();
        Globals.getFrame().repaint();
        Globals.getFrame().revalidate();
        iniciarMapInimigos();
        lblProta.setIcon(Globals.getProtagonista().getIcone());
        lblEnemy.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if(lblEnemy.isEnabled()){
                    Globals.getProtagonista().bater(enemy);
                }
            }
        }
        );

        DefaultComboBoxModel modelo = new DefaultComboBoxModel();

        for (int i = 0; i < mapa.size(); i++) {
            modelo.addElement(mapa.get(i).getNome());
        }
        cbxEnemy.setModel(modelo);

        btnStart.addMouseListener(
                new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {

                Globals.getProtagonista().setVida(Globals.getProtagonista().getVidaMaxima());
                lblEnemy.setEnabled(true);
                btnStart.setVisible(false);
                cbxEnemy.setVisible(false);
                lblEnemy.setVisible(true);
                lblVidaProta.setVisible(true);
                lblVidaEnemy.setVisible(true);
                lblEnemy.setIcon(mapa.get(cbxEnemy.getSelectedIndex()).getIcone());
                enemy = new Inimigo(mapa.get(cbxEnemy.getSelectedIndex()));
                enemy.setVida(enemy.getVidaMaxima());
                Thread tloop = new Thread(
                        new Runnable() {
                    public void run() {
                        gameLoop();
                    }
                });
                tloop.start();

            }
        }
        );
    }

    public void gameLoop() {
        try {
            int atackEnemy = enemy.getAttackSpeed();

            while (true) {
                atualizarInfos();
                if (Globals.getProtagonista().getVida() <= 0) {

                    fimLuta();
                    JOptionPane.showMessageDialog(null, "Você perdeu", "Falha", JOptionPane.ERROR_MESSAGE);

                    MP.escreverSave(Globals.getProtagonista());
                    return;
                }
                if (enemy.getVida() <= 0) {

                    fimLuta();
                    Globals.getProtagonista().somarXp(enemy.getXp_que_dropa());
                    Globals.getProtagonista().somarDinheiro(enemy.getDinheiro_que_dropa());
                    Globals.getProtagonista().uparNivel();

                    switch (enemy.getDropEspecial()) {
                        case "Roubo de vida":
                            Globals.getProtagonista().setPode_roubo_de_vida(true);
                            break;
                    }
                    MP.escreverSave(Globals.getProtagonista());
                    return;
                } else {

                    atackEnemy--;
                    if (atackEnemy <= 0) {
                        enemy.bater(Globals.getProtagonista());
                        atackEnemy = enemy.getAttackSpeed();
                    }
                }
                Thread.sleep(16);
            }
        } catch (InterruptedException exc) {

        }
    }

    public void iniciarComponentes() {
        lblVidaProta.setVisible(false);
        lblVidaEnemy.setVisible(false);
        lblEnemy.setEnabled(false);
        this.setBounds(0, 0, 800, 600);
    }

    public void fimLuta() {
        btnStart.setVisible(true);
        cbxEnemy.setVisible(true);
        lblEnemy.setVisible(false);
        lblVidaProta.setVisible(false);
        lblVidaEnemy.setVisible(false);
        lblEnemy.setEnabled(false);
        this.repaint();
        this.revalidate();
    }

    public void atualizarInfos() {
        lblVidaEnemy.setText("Vida: " + enemy.getVida());
        lblVidaProta.setText("Vida: " + Globals.getProtagonista().getVida());
    }

    public void iniciarMapInimigos() {
        //                      caminho            nome           vidaMaxima, dano, chanceCritica, MultiplicadorCritico, attackSpeed, dinheiro_que_dropa, xp_que_dropa
        final String inicioCaminho = "/clicker/imagens/";
        mapa.put(0, new Inimigo(inicioCaminho + "Bob_Esponja.png", "Bob Esponja", 50, 10, 24, 1.1, 120, 1, 3, ""));
        mapa.put(1, new Inimigo(inicioCaminho + "Rainha_de_copas.jpg", "Rainha de copas", 550, 22, 10, 1.2, 90, 2, 4, ""));
        mapa.put(2, new Inimigo(inicioCaminho + "Mario.jpg", "Mario", 900, 30, 10, 1.2, 130, 3, 6, ""));
        mapa.put(3, new Inimigo(inicioCaminho + "Sonic.jpg", "Sonic", 1000, 90, 10, 1.2, 70, 5, 7, ""));
        mapa.put(4, new Inimigo(inicioCaminho + "Shadow.jpg", "Shadow", 1200, 200, 35, 1.15, 65, 8, 11, "Roubo de vida"));
        mapa.put(5, new Inimigo(inicioCaminho + "Link.jpg", "Link", 2500, 300, 10, 1.4, 80, 13, 17, ""));
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnInfos = new javax.swing.JButton();
        lblVidaEnemy = new javax.swing.JLabel();
        lblEnemy = new javax.swing.JLabel();
        lblVidaProta = new javax.swing.JLabel();
        lblProta = new javax.swing.JLabel();
        cbxEnemy = new javax.swing.JComboBox<>();
        btnStart = new javax.swing.JButton();
        btnUpar = new javax.swing.JButton();
        btnLoja = new javax.swing.JButton();

        btnInfos.setText("Infos");
        btnInfos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInfosActionPerformed(evt);
            }
        });

        lblVidaEnemy.setText("Vida: ");

        lblVidaProta.setText("Vida:");

        cbxEnemy.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        btnStart.setText("Start");
        btnStart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnStartActionPerformed(evt);
            }
        });

        btnUpar.setText("Upar");
        btnUpar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUparActionPerformed(evt);
            }
        });

        btnLoja.setText("Loja");
        btnLoja.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLojaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(146, 146, 146)
                .addComponent(btnStart)
                .addGap(18, 18, 18)
                .addComponent(cbxEnemy, javax.swing.GroupLayout.PREFERRED_SIZE, 279, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(btnInfos)
                        .addGap(18, 18, 18)
                        .addComponent(btnUpar)
                        .addGap(18, 18, 18)
                        .addComponent(btnLoja))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(117, 117, 117)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblProta, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblVidaProta))
                        .addGap(141, 141, 141)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblEnemy, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblVidaEnemy))))
                .addContainerGap(158, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnLoja)
                    .addComponent(btnUpar)
                    .addComponent(btnInfos))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblVidaEnemy)
                        .addGap(18, 18, 18)
                        .addComponent(lblEnemy, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(62, 62, 62)
                        .addComponent(lblVidaProta)
                        .addGap(18, 18, 18)
                        .addComponent(lblProta, javax.swing.GroupLayout.PREFERRED_SIZE, 267, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(66, 66, 66)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cbxEnemy, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnStart, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(120, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnStartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnStartActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnStartActionPerformed

    private void btnInfosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInfosActionPerformed
        System.out.println("Clicado");
        Infos infos = new Infos();
        Globals.getLayer().add(infos, Globals.getLayer().getComponentCount() + 1);
        Globals.getLayer().setLayer(infos, Globals.getLayer().getComponentCount() + 1);
        infos.setBounds(
                (this.getWidth() * 1) / 8,
                (this.getHeight() * 1) / 8,
                (this.getWidth() * 3) / 4,
                (this.getHeight() * 3) / 4
        );
        infos.setVisible(true);
        Globals.getFrame().repaint();
        Globals.getFrame().revalidate();
        System.out.println("Feito");
    }//GEN-LAST:event_btnInfosActionPerformed

    private void btnUparActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUparActionPerformed
        Upar upar = new Upar();
        Globals.getLayer().add(upar, Globals.getLayer().getComponentCount() + 1);
        Globals.getLayer().setLayer(upar, Globals.getLayer().getComponentCount() + 1);
        upar.setBounds(
                (this.getWidth() * 1) / 8,
                (this.getHeight() * 1) / 8,
                (this.getWidth() * 3) / 4,
                (this.getHeight() * 3) / 4
        );
        upar.setVisible(true);
        Globals.getFrame().repaint();
        Globals.getFrame().revalidate();
    }//GEN-LAST:event_btnUparActionPerformed

    private void btnLojaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLojaActionPerformed
        Loja loja = new Loja();
        Globals.getLayer().add(loja, Globals.getLayer().getComponentCount() + 1);
        Globals.getLayer().setLayer(loja, Globals.getLayer().getComponentCount() + 1);
        loja.setBounds(
                (this.getWidth() * 1) / 8,
                (this.getHeight() * 1) / 8,
                (this.getWidth() * 3) / 4,
                (this.getHeight() * 3) / 4
        );
        loja.setVisible(true);
        Globals.getFrame().repaint();
        Globals.getFrame().revalidate();
    }//GEN-LAST:event_btnLojaActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnInfos;
    private javax.swing.JButton btnLoja;
    private javax.swing.JButton btnStart;
    private javax.swing.JButton btnUpar;
    private javax.swing.JComboBox<String> cbxEnemy;
    private javax.swing.JLabel lblEnemy;
    private javax.swing.JLabel lblProta;
    private javax.swing.JLabel lblVidaEnemy;
    private javax.swing.JLabel lblVidaProta;
    // End of variables declaration//GEN-END:variables
}

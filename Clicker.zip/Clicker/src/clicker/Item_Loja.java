//Soli Deo Gloria

package clicker;

import java.awt.Color;
import javax.swing.Timer;

public class Item_Loja extends javax.swing.JPanel {

    Item item;
    Loja loja;
    
    public Item_Loja(Item item, Loja loja) {
        this.item = item;
        this.loja = loja;
        initComponents();
        btnComprar.setBackground(new Color(255, 255, 255));
        atualizar();
    }
    public void atualizar() {
        
        lblPreco.setText("Preco: " + String.valueOf( item.getPreco() ) );
        lblIcone.setText("");
        lblIcone.setIcon( item.getIcone() );
        lblNome.setText(item.getNome());
        lblStatus.setText(item.getStatus());
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        lblPreco = new javax.swing.JLabel();
        btnComprar = new javax.swing.JButton();
        lblIcone = new javax.swing.JLabel();
        lblNome = new javax.swing.JLabel();
        lblStatus = new javax.swing.JLabel();

        setLayout(null);

        jPanel1.setBackground(new java.awt.Color(204, 255, 204));
        jPanel1.setForeground(new java.awt.Color(255, 255, 204));

        lblPreco.setText("Preco");

        btnComprar.setText("Comprar");
        btnComprar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnComprarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(lblPreco, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnComprar, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(btnComprar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
            .addComponent(lblPreco, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        add(jPanel1);
        jPanel1.setBounds(0, 0, 240, 50);

        lblIcone.setText("Imagem");
        add(lblIcone);
        lblIcone.setBounds(0, 50, 150, 190);

        lblNome.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblNome.setText("Nome");
        add(lblNome);
        lblNome.setBounds(10, 240, 260, 60);

        lblStatus.setText("Status");
        add(lblStatus);
        lblStatus.setBounds(160, 50, 80, 190);
    }// </editor-fold>//GEN-END:initComponents

    private void btnComprarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnComprarActionPerformed
        if(Globals.getProtagonista().getDinheiro() >= item.getPreco()) {
            Globals.getProtagonista().getInventario().add(item);
            Globals.getItens().remove(item.getPosicaoNoMap());
            loja.atualizar();
            btnComprar.setBackground(new Color(155, 255, 155));
            Timer timer = new Timer(300, mudarCor -> {
                btnComprar.setBackground( new Color(255, 255, 255));
            });
            timer.setRepeats(false);
            timer.start();
            
        } else {
            btnComprar.setBackground(Color.red);
            Timer timer = new Timer(300, mudarCor -> {
                btnComprar.setBackground( new Color(255, 255, 255));
            });
            timer.setRepeats(false);
            timer.start();
        }
        
    }//GEN-LAST:event_btnComprarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnComprar;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lblIcone;
    private javax.swing.JLabel lblNome;
    private javax.swing.JLabel lblPreco;
    private javax.swing.JLabel lblStatus;
    // End of variables declaration//GEN-END:variables
}

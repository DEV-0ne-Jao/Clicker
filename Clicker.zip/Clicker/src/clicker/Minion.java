//Soli Deo Gloria
package clicker;

import javax.swing.ImageIcon;
/*

//Soli Deo Gloria

package clicker;

import javax.swing.ImageIcon;

class Personagem {


    public Personagem(ImageIcon icone, String nome, int vidaMaxima, int dano, double chanceCritica, double MultiplicadorCritico) {
        this.icone = icone;
        this.nome = nome;
        this.vidaMaxima = vidaMaxima;
        this.vida = vidaMaxima;
        this.dano = dano;
        this.chanceCritica = chanceCritica;
        this.MultiplicadorCritico = MultiplicadorCritico;
    }
    public Personagem(String caminho, String nome, int vidaMaxima, int dano, double chanceCritica, double MultiplicadorCritico) {

    }
    
    public void bater(Personagem p){};




}


*/
class Minion extends Inventoravel{
    
    protected ImageIcon icone;
    protected String caminho;
    protected String nome;
    protected int vidaMaxima;
    protected int vida;
    protected int dano;
    protected double chanceCritica;
    protected double MultiplicadorCritico;
    
    private int attackSpeed;
    
    public Minion(String caminho, String nome, int vidaMaxima, int dano, double chanceCritica, double MultiplicadorCritico, int attackSpeed) {
        this.icone = new ImageIcon( getClass().getResource(caminho));
        this.caminho = caminho;
        this.nome = nome;
        this.vidaMaxima = vidaMaxima;
        this.vida = vidaMaxima;
        this.dano = dano;
        this.chanceCritica = chanceCritica;
        this.MultiplicadorCritico = MultiplicadorCritico;
        this.attackSpeed = attackSpeed;
    }
      
    public ImageIcon getIcone() {return icone;}
    public String getCaminho() {return this.caminho;}
    public String getNome() {return nome;}
    public int getVidaMaxima() {return vidaMaxima;}
    public int getVida() {return vida;}
    public int getDano() {return dano;}
    public double getChanceCritica() {return chanceCritica;}
    public double getMultiplicadorCritico() {return MultiplicadorCritico;}
    
    public void setIcone(ImageIcon icone) {this.icone = icone;}
    public void setCaminho(String caminho) {this.caminho = caminho;}
    public void setNome(String nome) {this.nome = nome;}
    public void setVidaMaxima(int vidaMaxima) {this.vidaMaxima = vidaMaxima;}
    public void setVida(int vida) {this.vida = vida;}
    public void setDano(int dano) {this.dano = dano;}
    public void setChanceCritica(double chanceCritica) {this.chanceCritica = chanceCritica;}
    public void setMultiplicadorCritico(double MultiplicadorCritico) {this.MultiplicadorCritico = MultiplicadorCritico;}
}

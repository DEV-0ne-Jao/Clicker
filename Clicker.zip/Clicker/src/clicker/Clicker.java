//Soli Deo Gloria
package clicker;
public class Clicker {
    public static void main(String[] args) {
        Protagonista p = new Protagonista("/clicker/imagens/cavaleiro_templario.jpg", "Eu", 50, 2, 0, 0, 0, 0, 7, 0, 0, new Inventario());
        JFramePrincipal jframe = new JFramePrincipal(p);
        jframe.setVisible(true);
        jframe.setEnabled(true);
        jframe.isActive();
    }
}
//Soli Deo Gloria

package clicker;

import javax.swing.ImageIcon;

class Personagem {
    protected ImageIcon icone;
    protected String nome;
    protected int vidaMaxima;
    protected int vida;
    protected int dano;
    protected int chanceCritica;
    protected double MultiplicadorCritico;

    public Personagem(ImageIcon icone, String nome, int vidaMaxima, int dano, int chanceCritica, double MultiplicadorCritico) {
        this.icone = icone;
        this.nome = nome;
        this.vidaMaxima = vidaMaxima;
        this.vida = vidaMaxima;
        this.dano = dano;
        this.chanceCritica = chanceCritica;
        this.MultiplicadorCritico = MultiplicadorCritico;
    }
    public Personagem(String caminho, String nome, int vidaMaxima, int dano, int chanceCritica, double MultiplicadorCritico) {
        this.icone = new ImageIcon(caminho);
        this.nome = nome;
        this.vidaMaxima = vidaMaxima;
        this.vida = vidaMaxima;
        this.dano = dano;
        this.chanceCritica = chanceCritica;
        this.MultiplicadorCritico = MultiplicadorCritico;
    }
    
    public void bater(Personagem p){};

    public ImageIcon getIcone() {return icone;}
    public String getNome() {return nome;}
    public int getVidaMaxima() {return vidaMaxima;}
    public int getVida() {return vida;}
    public int getDano() {return dano;}
    public int getChanceCritica() {return chanceCritica;}
    public double getMultiplicadorCritico() {return MultiplicadorCritico;}

    public void setIcone(ImageIcon icone) {this.icone = icone;}
    public void setNome(String nome) {this.nome = nome;}
    public void setVidaMaxima(int vidaMaxima) {this.vidaMaxima = vidaMaxima;}
    public void setVida(int vida) {this.vida = vida;}
    public void setDano(int dano) {this.dano = dano;}
    public void setChanceCritica(int chanceCritica) {this.chanceCritica = chanceCritica;}
    public void setMultiplicadorCritico(double MultiplicadorCritico) {this.MultiplicadorCritico = MultiplicadorCritico;}

}

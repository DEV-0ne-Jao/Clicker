//Soli Deo Gloria
package clicker;

import java.awt.Dimension;
import javax.swing.JScrollPane;

public class Loja extends javax.swing.JPanel {

    public Loja() {
        initComponents();
        scrollPanel.setPreferredSize(new Dimension(500, 340));
        panelLoja.setBounds(scrollPanel.getBounds());
        scrollPanel.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPanel.getVerticalScrollBar().setUnitIncrement(16);
        atualizar();
    }

    public void colocarItens() {
        int y = 5;
        int contador = 0;
        for (int i = 0; i < Globals.getItens().size(); i++) {
            Item item = Globals.getItens().get(i);
            item.setPosicaoNoMap(i);
            Item_Loja panelItem = new Item_Loja(item, this);
            panelItem.setVisible(true);
            panelLoja.add(panelItem);

            if (contador == 2) {
                contador = 0;
                y += 300 + 5;
            }

            if (contador == 1) {
                panelItem.setBounds((panelLoja.getBounds().width * 49) / 100, y, 240, 300);
                System.out.println((panelLoja.getBounds().width));
            } else {
                panelItem.setBounds((panelLoja.getBounds().width * 1) / 100, y, 240, 300);
            }
            contador++;

            panelLoja.setPreferredSize(new Dimension(500, panelItem.getBounds().y + panelItem.getBounds().height + 10));
            panelLoja.setBounds(0, 0, 500, panelItem.getBounds().y + panelItem.getBounds().height + 10);
        }
    }

    public void atualizar() {
        colocarItens();
        
        Globals.getFrame().repaint();
        Globals.getFrame().revalidate();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblNomeLoja = new javax.swing.JLabel();
        btnVoltar = new javax.swing.JButton();
        scrollPanel = new javax.swing.JScrollPane();
        panelLoja = new javax.swing.JPanel();

        setBackground(new java.awt.Color(255, 255, 204));

        lblNomeLoja.setFont(new java.awt.Font("Segoe UI", 1, 40)); // NOI18N
        lblNomeLoja.setText("Lojinhaaaaaaa :)");

        btnVoltar.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        btnVoltar.setText("Voltar");
        btnVoltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVoltarActionPerformed(evt);
            }
        });

        scrollPanel.setBorder(null);
        scrollPanel.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPanel.setToolTipText("");
        scrollPanel.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

        panelLoja.setBackground(new java.awt.Color(204, 204, 204));
        panelLoja.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        panelLoja.setLayout(null);
        scrollPanel.setViewportView(panelLoja);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(scrollPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 500, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lblNomeLoja, javax.swing.GroupLayout.PREFERRED_SIZE, 352, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnVoltar, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(11, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblNomeLoja)
                    .addComponent(btnVoltar, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(11, 11, 11)
                .addComponent(scrollPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 340, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnVoltarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVoltarActionPerformed
        Globals.getLayer().remove(this);
        Globals.getFrame().repaint();
        Globals.getFrame().revalidate();
    }//GEN-LAST:event_btnVoltarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnVoltar;
    private javax.swing.JLabel lblNomeLoja;
    private javax.swing.JPanel panelLoja;
    private javax.swing.JScrollPane scrollPanel;
    // End of variables declaration//GEN-END:variables
}

//Soli Deo Gloria
package clicker;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JLayeredPane;

public class Upar extends javax.swing.JPanel {

    public Protagonista p;
    public JLayeredPane layer;

    public Upar(JLayeredPane layer, Protagonista p) {
        initComponents();
        this.layer = layer;
        this.p = p;
        atualizarinfos();

        MouseAdapter m = new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (e.getSource() == btnVida) {
                    p.setVidaMaxima(p.getVidaMaxima() + 5);
                    p.setPontos_de_status(p.getPontos_de_status() - 1);
                    atualizarinfos();
                } else if (e.getSource() == btnDano) {
                    p.setDano(p.getDano() + 1);
                    p.setPontos_de_status(p.getPontos_de_status() - 1);
                    atualizarinfos();
                } else if (e.getSource() == btnChance) {
                    p.setChanceCritica(p.getChanceCritica() + 0.5);
                    p.setPontos_de_status(p.getPontos_de_status() - 1);
                    atualizarinfos();
                } else if (e.getSource() == btnMult) {
                    p.setMultiplicadorCritico(p.getMultiplicadorCritico() + 0.7);
                    p.setPontos_de_status(p.getPontos_de_status() - 1);
                    atualizarinfos();
                } else if (e.getSource() == btnRoubo) {
                    p.setRoubo_de_vida(p.getRoubo_de_vida() + 0.2);
                    p.setPontos_de_status(p.getPontos_de_status() - 1);
                    atualizarinfos();

                }
            }
        };

        btnVida.addMouseListener(m);
        btnDano.addMouseListener(m);
        btnChance.addMouseListener(m);
        btnMult.addMouseListener(m);
        btnRoubo.addMouseListener(m);
    }

    public void atualizarinfos() {
        l_Vida.setText("Vida máxima: " + p.getVidaMaxima());
        l_Dano.setText("Dano: " + p.getDano());
        l_ChanceCritica.setText("Chance crítica: " + p.getChanceCritica());
        l_MultiplicadorCritico.setText("Multiplicador crítico: " + p.getMultiplicadorCritico());
        l_RouboDeVida.setText("Roubo de vida: " + p.getRoubo_de_vida());
        l_pts.setText("Pontos restantes: " + p.getPontos_de_status());

        if (!p.isPode_roubo_de_vida()) {
            btnRoubo.setEnabled(false);
        } else {
            btnRoubo.setEnabled(true);
        }

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        l_Vida = new javax.swing.JLabel();
        l_Dano = new javax.swing.JLabel();
        l_ChanceCritica = new javax.swing.JLabel();
        l_MultiplicadorCritico = new javax.swing.JLabel();
        l_RouboDeVida = new javax.swing.JLabel();
        btnVida = new javax.swing.JButton();
        btnDano = new javax.swing.JButton();
        btnChance = new javax.swing.JButton();
        btnMult = new javax.swing.JButton();
        btnRoubo = new javax.swing.JButton();
        l_pts = new javax.swing.JLabel();
        btnSair = new javax.swing.JButton();

        setBackground(new java.awt.Color(255, 255, 204));

        l_Vida.setText("Vida:");

        l_Dano.setText("Dano:");

        l_ChanceCritica.setText("Chance Crítica:");

        l_MultiplicadorCritico.setText("Multiplicador Crítico:");

        l_RouboDeVida.setText("Roubo de Vida:");

        btnVida.setText("+");

        btnDano.setText("+");

        btnChance.setText("+");

        btnMult.setText("+");

        btnRoubo.setText("+");

        l_pts.setText("Pontos restantes:");

        btnSair.setText("Sair");
        btnSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSairActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(l_Dano, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(l_Vida, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(l_MultiplicadorCritico, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(l_ChanceCritica, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(l_pts, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(l_RouboDeVida, javax.swing.GroupLayout.Alignment.TRAILING))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnVida, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnDano, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnChance, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnMult, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnRoubo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(104, 104, 104)
                .addComponent(btnSair)
                .addContainerGap(32, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(l_Vida, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnVida, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                    .addComponent(btnSair))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnDano, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(l_Dano, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(l_ChanceCritica)
                    .addComponent(btnChance, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(l_MultiplicadorCritico)
                    .addComponent(btnMult, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(l_RouboDeVida)
                    .addComponent(btnRoubo, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addGap(29, 29, 29)
                .addComponent(l_pts)
                .addContainerGap(48, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSairActionPerformed
        layer.remove(this);
        layer.repaint();
    }//GEN-LAST:event_btnSairActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnChance;
    private javax.swing.JButton btnDano;
    private javax.swing.JButton btnMult;
    private javax.swing.JButton btnRoubo;
    private javax.swing.JButton btnSair;
    private javax.swing.JButton btnVida;
    private javax.swing.JLabel l_ChanceCritica;
    private javax.swing.JLabel l_Dano;
    private javax.swing.JLabel l_MultiplicadorCritico;
    private javax.swing.JLabel l_RouboDeVida;
    private javax.swing.JLabel l_Vida;
    private javax.swing.JLabel l_pts;
    // End of variables declaration//GEN-END:variables
}

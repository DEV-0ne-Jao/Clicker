//Soli Deo Gloria
package clicker;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;

public class Upar extends javax.swing.JPanel {

    public JLayeredPane layer;

    public Upar(JLayeredPane layer) {
        initComponents();
        this.layer = layer;
        atualizarinfos();

        MouseAdapter m = new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (Globals.protagonista.getPontos_de_status() > 0) {
                    if (e.getSource() == btnVida) {
                        Globals.protagonista.setVidaMaxima(Globals.protagonista.getVidaMaxima() + 5);
                        Globals.protagonista.setPontos_de_status(Globals.protagonista.getPontos_de_status() - 1);
                        atualizarinfos();
                    } else if (e.getSource() == btnDano) {
                        Globals.protagonista.setDano(Globals.protagonista.getDano() + 1);
                        Globals.protagonista.setPontos_de_status(Globals.protagonista.getPontos_de_status() - 1);
                        atualizarinfos();
                    } else if (e.getSource() == btnChance) {
                        Globals.protagonista.setChanceCritica(Globals.protagonista.getChanceCritica() + 0.5);
                        Globals.protagonista.setPontos_de_status(Globals.protagonista.getPontos_de_status() - 1);
                        atualizarinfos();
                    } else if (e.getSource() == btnMult) {
                        Globals.protagonista.setMultiplicadorCritico(Globals.protagonista.getMultiplicadorCritico() + 0.7);
                        Globals.protagonista.setPontos_de_status(Globals.protagonista.getPontos_de_status() - 1);
                        atualizarinfos();
                    } else if (e.getSource() == btnRoubo) {
                        Globals.protagonista.setRoubo_de_vida(Globals.protagonista.getRoubo_de_vida() + 0.2);
                        Globals.protagonista.setPontos_de_status(Globals.protagonista.getPontos_de_status() - 1);
                        atualizarinfos();

                    }
                } else {
                    JOptionPane.showMessageDialog(null,"Pontos insuficientes", "Erro", JOptionPane.ERROR_MESSAGE);
                }
            }
        };

        btnVida.addMouseListener(m);
        btnDano.addMouseListener(m);
        btnChance.addMouseListener(m);
        btnMult.addMouseListener(m);
        btnRoubo.addMouseListener(m);
    }

    public void atualizarinfos() {
        l_Vida.setText("Vida máxima: " + Globals.protagonista.getVidaMaxima());
        l_Dano.setText("Dano: " + Globals.protagonista.getDano());
        l_ChanceCritica.setText("Chance crítica: " + Globals.protagonista.getChanceCritica());
        l_MultiplicadorCritico.setText("Multiplicador crítico: " + Globals.protagonista.getMultiplicadorCritico());
        l_RouboDeVida.setText("Roubo de vida: " + Globals.protagonista.getRoubo_de_vida());
        l_pts.setText("Pontos restantes: " + Globals.protagonista.getPontos_de_status());

        if (!Globals.protagonista.isPode_roubo_de_vida()) {
            btnRoubo.setEnabled(false);
        } else {
            btnRoubo.setEnabled(true);
        }

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        l_Vida = new javax.swing.JLabel();
        l_Dano = new javax.swing.JLabel();
        l_ChanceCritica = new javax.swing.JLabel();
        l_MultiplicadorCritico = new javax.swing.JLabel();
        l_RouboDeVida = new javax.swing.JLabel();
        btnVida = new javax.swing.JButton();
        btnDano = new javax.swing.JButton();
        btnChance = new javax.swing.JButton();
        btnMult = new javax.swing.JButton();
        btnRoubo = new javax.swing.JButton();
        l_pts = new javax.swing.JLabel();
        btnSair = new javax.swing.JButton();
        btnDeletarSave = new javax.swing.JButton();

        setBackground(new java.awt.Color(255, 255, 204));

        l_Vida.setText("Vida:");

        l_Dano.setText("Dano:");

        l_ChanceCritica.setText("Chance Crítica:");

        l_MultiplicadorCritico.setText("Multiplicador Crítico:");

        l_RouboDeVida.setText("Roubo de Vida:");

        btnVida.setText("+");

        btnDano.setText("+");

        btnChance.setText("+");

        btnMult.setText("+");

        btnRoubo.setText("+");

        l_pts.setText("Pontos restantes:");

        btnSair.setText("Sair");
        btnSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSairActionPerformed(evt);
            }
        });

        btnDeletarSave.setText("Deletar save");
        btnDeletarSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeletarSaveActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(l_Dano, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(l_Vida, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(l_MultiplicadorCritico, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(l_ChanceCritica, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(l_pts, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(l_RouboDeVida, javax.swing.GroupLayout.Alignment.TRAILING))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnVida, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnDano, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnChance, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnMult, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnRoubo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(94, 94, 94)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnDeletarSave, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnSair, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(45, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnVida, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(l_Vida, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnDano, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(l_Dano, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnChance, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(l_ChanceCritica, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnMult, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(l_MultiplicadorCritico, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnRoubo)
                    .addComponent(l_RouboDeVida, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(29, 29, 29)
                .addComponent(l_pts)
                .addContainerGap(34, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(btnSair)
                .addGap(87, 87, 87)
                .addComponent(btnDeletarSave)
                .addGap(30, 30, 30))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSairActionPerformed
        layer.remove(this);
        layer.repaint();
    }//GEN-LAST:event_btnSairActionPerformed

    private void btnDeletarSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeletarSaveActionPerformed
        MP.apagarSave();
        Globals.protagonista = MP.lerSave();
        atualizarinfos();
    }//GEN-LAST:event_btnDeletarSaveActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnChance;
    private javax.swing.JButton btnDano;
    private javax.swing.JButton btnDeletarSave;
    private javax.swing.JButton btnMult;
    private javax.swing.JButton btnRoubo;
    private javax.swing.JButton btnSair;
    private javax.swing.JButton btnVida;
    private javax.swing.JLabel l_ChanceCritica;
    private javax.swing.JLabel l_Dano;
    private javax.swing.JLabel l_MultiplicadorCritico;
    private javax.swing.JLabel l_RouboDeVida;
    private javax.swing.JLabel l_Vida;
    private javax.swing.JLabel l_pts;
    // End of variables declaration//GEN-END:variables
}

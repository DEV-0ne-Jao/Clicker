//Soli Deo Gloria
package clicker;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.HashMap;
import java.util.Map;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

public class Battle extends javax.swing.JPanel {

    public static HashMap<Integer, Inimigo> mapa = new HashMap<>();
    public static Inimigo enemy;
    public static Protagonista protagonista;

    /*
    icone OU caminho, nome, vidaMaxima, dano, chanceCritica, MultiplicadorCritico, dinheiro, nivel, xp_paraUpar,
    xp, pontos_de_status, pode_roubo_de_vida, roubo_de_vida, Inventario
     */
    public Battle(JFrame frame, Protagonista prota) {
        Battle b = this;
        protagonista = prota;
        this.setBounds(0, 0, frame.getWidth(), frame.getHeight());
        initComponents();
        iniciarComponentes();
        frame.repaint();
        frame.revalidate();
        iniciarMapInimigos();
        Layer.setLayer(PanelBattle, 0);
        lblProta.setIcon(protagonista.getIcone());
        lblEnemy.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                protagonista.bater(enemy);
            }
        }
        );

        DefaultComboBoxModel modelo = new DefaultComboBoxModel();

        for (int i = 0; i < mapa.size(); i++) {
            modelo.addElement(mapa.get(i).getNome());
        }
        cbxEnemy.setModel(modelo);

        btnStart.addMouseListener(
                new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {

                protagonista.setVida(protagonista.getVidaMaxima());
                btnStart.setVisible(false);
                cbxEnemy.setVisible(false);
                lblEnemy.setVisible(true);
                lblVidaProta.setVisible(true);
                lblVidaEnemy.setVisible(true);
                lblEnemy.setIcon(mapa.get(cbxEnemy.getSelectedIndex()).getIcone());
                enemy = new Inimigo(mapa.get(cbxEnemy.getSelectedIndex()));
                enemy.setVida(enemy.getVidaMaxima());
                Thread tloop = new Thread(
                        new Runnable() {
                    public void run() {
                        gameLoop();
                    }
                });
                tloop.start();

            }
        }
        );
        btnInfos.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                Infos info = new Infos(Layer, protagonista);
                Layer.add(info);
                Layer.setLayer(info, 1);
                info.setBounds(200, 200, 400, 300);
                info.setVisible(true);

            }
        });
        btnUpar.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                Upar painel = new Upar(Layer, protagonista);
                Layer.add(painel);
                Layer.setLayer(painel, 1);
                painel.setBounds(200, 200, 400, 300);
                painel.setVisible(true);

            }
        });
    }

    public void gameLoop() {
        try {
            int atackEnemy = enemy.getAttackSpeed();

            while (true) {
                atualizarInfos();
                if (protagonista.getVida() <= 0) {

                    fimLuta();
                    JOptionPane.showMessageDialog(null, "Você perdeu", "Falha", JOptionPane.ERROR_MESSAGE);
                    ManipuladorDeArquivo mp = new ManipuladorDeArquivo();
                    mp.escreverSave(protagonista);
                    return;
                }
                if (enemy.getVida() <= 0) {

                    fimLuta();
                    protagonista.somarXp(enemy.getXp_que_dropa());
                    protagonista.setDinheiro(enemy.getDinheiro_que_dropa());
                    protagonista.uparNivel();
                    ManipuladorDeArquivo mp = new ManipuladorDeArquivo();
                    mp.escreverSave(protagonista);
                    return;
                } else {

                    atackEnemy--;
                    if (atackEnemy <= 0) {
                        enemy.bater(protagonista);
                        atackEnemy = enemy.getAttackSpeed();
                    }
                }
                Thread.sleep(16);
            }
        } catch (InterruptedException exc) {

        }
    }

    public void iniciarComponentes() {
        lblVidaProta.setVisible(false);
        lblVidaEnemy.setVisible(false);
        Layer.setBounds(0, 0, 800, 600);
        PanelBattle.setBounds(0, 0, 800, 600);
        Layer.setLayer(PanelBattle, 0);
    }

    public void fimLuta() {
        btnStart.setVisible(true);
        cbxEnemy.setVisible(true);
        lblEnemy.setVisible(false);
        lblVidaProta.setVisible(false);
        lblVidaEnemy.setVisible(false);
        this.repaint();
        this.revalidate();
    }

    public void atualizarInfos() {
        lblVidaEnemy.setText("Vida: " + enemy.getVida());
        lblVidaProta.setText("Vida: " + protagonista.getVida());
    }

    public void iniciarMapInimigos() {
        //                      caminho            nome           vidaMaxima, dano, chanceCritica, MultiplicadorCritico, attackSpeed, dinheiro_que_dropa, xp_que_dropa
        final String inicioCaminho = "/clicker/imagens/";
        mapa.put(0, new Inimigo(inicioCaminho + "Bob_Esponja.png", "Bob Esponja", 50, 10, 24, 1.1, 120, 1, 3));
        mapa.put(1, new Inimigo(inicioCaminho + "Rainha_de_copas.jpg", "Rainha de copas", 550, 22, 10, 1.2, 90, 2, 4));
        mapa.put(2, new Inimigo(inicioCaminho + "Mario.jpg", "Mario", 900, 30, 10, 1.2, 130, 3, 6));
        mapa.put(3, new Inimigo(inicioCaminho + "Sonic.jpg", "Sonic", 1000, 90, 10, 1.2, 70, 5, 7));
        mapa.put(4, new Inimigo(inicioCaminho + "Shadow.jpg", "Shadow", 1200, 200, 35, 1.15, 65, 8, 11));
        mapa.put(5, new Inimigo(inicioCaminho + "Link.jpg", "Link", 2500, 300, 10, 1.4, 80, 13, 17));
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Layer = new javax.swing.JLayeredPane();
        PanelBattle = new javax.swing.JPanel();
        btnInfos = new javax.swing.JButton();
        lblVidaEnemy = new javax.swing.JLabel();
        lblEnemy = new javax.swing.JLabel();
        lblVidaProta = new javax.swing.JLabel();
        lblProta = new javax.swing.JLabel();
        cbxEnemy = new javax.swing.JComboBox<>();
        btnStart = new javax.swing.JButton();
        btnUpar = new javax.swing.JButton();

        Layer.setOpaque(true);

        btnInfos.setText("Infos");
        btnInfos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInfosActionPerformed(evt);
            }
        });

        lblVidaEnemy.setText("Vida: ");

        lblVidaProta.setText("Vida:");

        cbxEnemy.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        btnStart.setText("Start");
        btnStart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnStartActionPerformed(evt);
            }
        });

        btnUpar.setText("Upar");
        btnUpar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUparActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout PanelBattleLayout = new javax.swing.GroupLayout(PanelBattle);
        PanelBattle.setLayout(PanelBattleLayout);
        PanelBattleLayout.setHorizontalGroup(
            PanelBattleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelBattleLayout.createSequentialGroup()
                .addGroup(PanelBattleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelBattleLayout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(btnStart)
                        .addGap(18, 18, 18)
                        .addComponent(cbxEnemy, javax.swing.GroupLayout.PREFERRED_SIZE, 279, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(PanelBattleLayout.createSequentialGroup()
                        .addGap(94, 94, 94)
                        .addGroup(PanelBattleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(PanelBattleLayout.createSequentialGroup()
                                .addComponent(lblProta, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(137, 137, 137)
                                .addComponent(lblEnemy, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(btnUpar))))
                .addContainerGap(173, Short.MAX_VALUE))
            .addGroup(PanelBattleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(PanelBattleLayout.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(PanelBattleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(PanelBattleLayout.createSequentialGroup()
                            .addGap(105, 105, 105)
                            .addComponent(lblVidaProta)
                            .addGap(295, 295, 295)
                            .addComponent(lblVidaEnemy))
                        .addComponent(btnInfos))
                    .addContainerGap(339, Short.MAX_VALUE)))
        );
        PanelBattleLayout.setVerticalGroup(
            PanelBattleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelBattleLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnUpar)
                .addGap(73, 73, 73)
                .addGroup(PanelBattleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lblProta, javax.swing.GroupLayout.PREFERRED_SIZE, 267, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblEnemy, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(53, 53, 53)
                .addGroup(PanelBattleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cbxEnemy, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnStart, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(143, 143, 143))
            .addGroup(PanelBattleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(PanelBattleLayout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(btnInfos)
                    .addGap(16, 16, 16)
                    .addGroup(PanelBattleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lblVidaEnemy)
                        .addComponent(lblVidaProta))
                    .addContainerGap(539, Short.MAX_VALUE)))
        );

        Layer.setLayer(PanelBattle, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout LayerLayout = new javax.swing.GroupLayout(Layer);
        Layer.setLayout(LayerLayout);
        LayerLayout.setHorizontalGroup(
            LayerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(PanelBattle, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        LayerLayout.setVerticalGroup(
            LayerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(PanelBattle, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Layer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Layer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnStartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnStartActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnStartActionPerformed

    private void btnInfosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInfosActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnInfosActionPerformed

    private void btnUparActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUparActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnUparActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLayeredPane Layer;
    private javax.swing.JPanel PanelBattle;
    private javax.swing.JButton btnInfos;
    private javax.swing.JButton btnStart;
    private javax.swing.JButton btnUpar;
    private javax.swing.JComboBox<String> cbxEnemy;
    private javax.swing.JLabel lblEnemy;
    private javax.swing.JLabel lblProta;
    private javax.swing.JLabel lblVidaEnemy;
    private javax.swing.JLabel lblVidaProta;
    // End of variables declaration//GEN-END:variables
}

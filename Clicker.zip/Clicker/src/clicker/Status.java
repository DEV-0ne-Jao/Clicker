//Soli Deo Gloria
package clicker;

public class Status {
    private String nome = "";
    private int atributoInt = 0;
    private double atributoDouble = 0.0;
    private String descricao = "";
    
    public Status(String nome, int atributoInt) {
        this.nome = nome;
        this.atributoInt = atributoInt;
    }
    public Status(String nome, double atributoDouble) {
        this.nome = nome;
        this.atributoDouble = atributoDouble;
    }

    public String getNome() {return nome;}
    public int getAtributoInt() {return atributoInt;}
    public double getAtributoDouble() {return atributoDouble;}
    
    public void setNome(String nome) {this.nome = nome;}
    public void setAtributoInt(int atributoInt) {this.atributoInt = atributoInt;}
    public void setAtributoDouble(double atributoDouble) {this.atributoDouble = atributoDouble;}
    
}

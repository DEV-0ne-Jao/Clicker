//Soli Deo Gloria

package clicker;
public class Inventario {
    private Minion[] minions;
}
